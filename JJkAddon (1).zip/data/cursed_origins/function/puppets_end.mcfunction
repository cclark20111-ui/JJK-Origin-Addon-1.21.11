execute at @e[type=minecraft:zombie,tag=cursed_origins_puppet] run particle minecraft:poof ~ ~1 ~ 0.3 0.5 0.3 0.05 15
kill @e[type=minecraft:zombie,tag=cursed_origins_puppet]
