execute as @e[tag=cursed_origins_blast_fall] run attribute @s minecraft:safe_fall_distance modifier remove cursed_origins:blast_fall
tag @e[tag=cursed_origins_blast_fall] remove cursed_origins_blast_fall
