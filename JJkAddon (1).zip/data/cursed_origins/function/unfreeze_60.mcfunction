execute as @e[tag=cursed_origins_frozen_60] run attribute @s minecraft:jump_strength modifier remove cursed_origins:frozen_60
tag @e[tag=cursed_origins_frozen_60] remove cursed_origins_frozen_60
