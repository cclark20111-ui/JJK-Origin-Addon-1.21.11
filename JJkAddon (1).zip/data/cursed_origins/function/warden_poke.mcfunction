execute as @e[type=minecraft:warden,tag=cursed_origins_warden] at @s if entity @e[tag=cursed_origins_warden_target] run damage @s 0.5 minecraft:mob_attack by @e[tag=cursed_origins_warden_target,limit=1,sort=nearest]
execute if entity @e[type=minecraft:warden,tag=cursed_origins_warden] run schedule function cursed_origins:warden_poke 60t
