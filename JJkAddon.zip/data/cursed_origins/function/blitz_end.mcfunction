effect give @a[tag=cursed_origins_blitz] minecraft:wither 8 1
title @a[tag=cursed_origins_blitz] actionbar {"text":"The rush fades - the strain sets in.","color":"dark_gray"}
tag @a[tag=cursed_origins_blitz] remove cursed_origins_blitz
