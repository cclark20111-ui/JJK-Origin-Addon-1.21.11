execute as @e[tag=cursed_origins_divergent] at @s run damage @s 8 minecraft:magic
execute at @e[tag=cursed_origins_divergent] run particle minecraft:dust{color:[0.03,0.0,0.06],scale:2.0} ~ ~1 ~ 0.5 0.8 0.5 0 60
execute at @e[tag=cursed_origins_divergent] run particle minecraft:electric_spark ~ ~1 ~ 0.5 0.8 0.5 0.4 40
execute at @e[tag=cursed_origins_divergent] run playsound minecraft:entity.lightning_bolt.impact master @a ~ ~ ~ 1.2 1.6
tag @e[tag=cursed_origins_divergent] remove cursed_origins_divergent
