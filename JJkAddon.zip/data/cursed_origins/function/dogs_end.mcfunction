execute at @e[type=minecraft:wolf,tag=cursed_origins_dog] run particle minecraft:smoke ~ ~0.5 ~ 0.3 0.4 0.3 0.03 30
kill @e[type=minecraft:wolf,tag=cursed_origins_dog]
