effect give @a[tag=cursed_origins_overtime] minecraft:slowness 8 1 true
effect give @a[tag=cursed_origins_overtime] minecraft:weakness 8 1 true
title @a[tag=cursed_origins_overtime] actionbar {"text":"Overtime is over. You are exhausted.","color":"gray"}
tag @a[tag=cursed_origins_overtime] remove cursed_origins_overtime
