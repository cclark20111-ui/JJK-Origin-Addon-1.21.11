execute at @e[type=minecraft:rabbit,tag=cursed_origins_rabbit] run particle minecraft:poof ~ ~0.3 ~ 0.2 0.2 0.2 0.05 8
kill @e[type=minecraft:rabbit,tag=cursed_origins_rabbit]
