execute at @e[type=minecraft:phantom,tag=cursed_origins_spirit] run particle minecraft:soul_fire_flame ~ ~0.5 ~ 0.3 0.4 0.3 0.03 20
kill @e[type=minecraft:phantom,tag=cursed_origins_spirit]
