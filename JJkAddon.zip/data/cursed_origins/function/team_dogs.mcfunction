$team add cs$(id)
$execute as @s[team=] run team join cs$(id) @s
$team join cs$(id) @e[tag=cursed_origins_dog_new]
