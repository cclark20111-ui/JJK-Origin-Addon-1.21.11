execute as @e[tag=cursed_origins_frozen_100] run attribute @s minecraft:jump_strength modifier remove cursed_origins:frozen_100
tag @e[tag=cursed_origins_frozen_100] remove cursed_origins_frozen_100
