execute as @e[tag=cursed_origins_frozen_20] run attribute @s minecraft:jump_strength modifier remove cursed_origins:frozen_20
tag @e[tag=cursed_origins_frozen_20] remove cursed_origins_frozen_20
