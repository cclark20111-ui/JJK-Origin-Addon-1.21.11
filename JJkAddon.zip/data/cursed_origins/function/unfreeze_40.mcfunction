execute as @e[tag=cursed_origins_frozen_40] run attribute @s minecraft:jump_strength modifier remove cursed_origins:frozen_40
tag @e[tag=cursed_origins_frozen_40] remove cursed_origins_frozen_40
