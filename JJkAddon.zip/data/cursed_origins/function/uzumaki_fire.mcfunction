execute at @e[tag=cursed_origins_uzu_beast] run playsound minecraft:entity.warden.sonic_boom master @a ~ ~ ~ 2.0 0.8
execute at @e[tag=cursed_origins_uzu_beast] run playsound minecraft:entity.generic.explode master @a ~ ~ ~ 1.2 0.6
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^1 run particle minecraft:dragon_breath ~ ~ ~ 0.7 0.7 0.7 0.03 10
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^2 run particle minecraft:dragon_breath ~ ~ ~ 0.7 0.7 0.7 0.03 10
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^3 run particle minecraft:dragon_breath ~ ~ ~ 0.7 0.7 0.7 0.03 10
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^4 run particle minecraft:dragon_breath ~ ~ ~ 0.7 0.7 0.7 0.03 10
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^5 run particle minecraft:dragon_breath ~ ~ ~ 0.7 0.7 0.7 0.03 10
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^6 run particle minecraft:dragon_breath ~ ~ ~ 0.7 0.7 0.7 0.03 10
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^7 run particle minecraft:dragon_breath ~ ~ ~ 0.7 0.7 0.7 0.03 10
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^8 run particle minecraft:dragon_breath ~ ~ ~ 0.7 0.7 0.7 0.03 10
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^9 run particle minecraft:dragon_breath ~ ~ ~ 0.7 0.7 0.7 0.03 10
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^10 run particle minecraft:dragon_breath ~ ~ ~ 0.7 0.7 0.7 0.03 10
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^11 run particle minecraft:dragon_breath ~ ~ ~ 0.7 0.7 0.7 0.03 10
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^12 run particle minecraft:dragon_breath ~ ~ ~ 0.7 0.7 0.7 0.03 10
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^13 run particle minecraft:dragon_breath ~ ~ ~ 0.7 0.7 0.7 0.03 10
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^14 run particle minecraft:dragon_breath ~ ~ ~ 0.7 0.7 0.7 0.03 10
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^1 run particle minecraft:soul_fire_flame ~ ~ ~ 0.4 0.4 0.4 0.02 4
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^2 run particle minecraft:soul_fire_flame ~ ~ ~ 0.4 0.4 0.4 0.02 4
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^3 run particle minecraft:soul_fire_flame ~ ~ ~ 0.4 0.4 0.4 0.02 4
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^4 run particle minecraft:soul_fire_flame ~ ~ ~ 0.4 0.4 0.4 0.02 4
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^5 run particle minecraft:soul_fire_flame ~ ~ ~ 0.4 0.4 0.4 0.02 4
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^6 run particle minecraft:soul_fire_flame ~ ~ ~ 0.4 0.4 0.4 0.02 4
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^7 run particle minecraft:soul_fire_flame ~ ~ ~ 0.4 0.4 0.4 0.02 4
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^8 run particle minecraft:soul_fire_flame ~ ~ ~ 0.4 0.4 0.4 0.02 4
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^9 run particle minecraft:soul_fire_flame ~ ~ ~ 0.4 0.4 0.4 0.02 4
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^10 run particle minecraft:soul_fire_flame ~ ~ ~ 0.4 0.4 0.4 0.02 4
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^11 run particle minecraft:soul_fire_flame ~ ~ ~ 0.4 0.4 0.4 0.02 4
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^12 run particle minecraft:soul_fire_flame ~ ~ ~ 0.4 0.4 0.4 0.02 4
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^13 run particle minecraft:soul_fire_flame ~ ~ ~ 0.4 0.4 0.4 0.02 4
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^14 run particle minecraft:soul_fire_flame ~ ~ ~ 0.4 0.4 0.4 0.02 4
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^2 as @e[distance=..1.68,tag=!cursed_origins_uzu_actor,tag=!cursed_origins_uzu_beast,tag=!cursed_origins_spirit,type=!minecraft:marker,type=!minecraft:item,type=!minecraft:area_effect_cloud,type=!minecraft:experience_orb] if data entity @s Health run tag @s add cursed_origins_uzu_victim
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^4 as @e[distance=..1.76,tag=!cursed_origins_uzu_actor,tag=!cursed_origins_uzu_beast,tag=!cursed_origins_spirit,type=!minecraft:marker,type=!minecraft:item,type=!minecraft:area_effect_cloud,type=!minecraft:experience_orb] if data entity @s Health run tag @s add cursed_origins_uzu_victim
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^6 as @e[distance=..1.84,tag=!cursed_origins_uzu_actor,tag=!cursed_origins_uzu_beast,tag=!cursed_origins_spirit,type=!minecraft:marker,type=!minecraft:item,type=!minecraft:area_effect_cloud,type=!minecraft:experience_orb] if data entity @s Health run tag @s add cursed_origins_uzu_victim
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^8 as @e[distance=..1.92,tag=!cursed_origins_uzu_actor,tag=!cursed_origins_uzu_beast,tag=!cursed_origins_spirit,type=!minecraft:marker,type=!minecraft:item,type=!minecraft:area_effect_cloud,type=!minecraft:experience_orb] if data entity @s Health run tag @s add cursed_origins_uzu_victim
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^10 as @e[distance=..2.0,tag=!cursed_origins_uzu_actor,tag=!cursed_origins_uzu_beast,tag=!cursed_origins_spirit,type=!minecraft:marker,type=!minecraft:item,type=!minecraft:area_effect_cloud,type=!minecraft:experience_orb] if data entity @s Health run tag @s add cursed_origins_uzu_victim
execute as @e[tag=cursed_origins_uzu_beast] at @s positioned ^ ^ ^12 as @e[distance=..2.08,tag=!cursed_origins_uzu_actor,tag=!cursed_origins_uzu_beast,tag=!cursed_origins_spirit,type=!minecraft:marker,type=!minecraft:item,type=!minecraft:area_effect_cloud,type=!minecraft:experience_orb] if data entity @s Health run tag @s add cursed_origins_uzu_victim
execute as @e[tag=cursed_origins_uzu_victim] at @s run damage @s 8 minecraft:magic
execute at @e[tag=cursed_origins_uzu_victim] run particle minecraft:soul_fire_flame ~ ~1 ~ 0.5 0.9 0.5 0.1 50
execute at @e[tag=cursed_origins_uzu_victim] run playsound minecraft:entity.warden.sonic_boom master @a ~ ~ ~ 1.2 1.4
tag @e[tag=cursed_origins_uzu_victim] remove cursed_origins_uzu_victim
kill @e[type=minecraft:phantom,tag=cursed_origins_uzu_beast]
tag @e[tag=cursed_origins_uzu_actor] remove cursed_origins_uzu_actor
