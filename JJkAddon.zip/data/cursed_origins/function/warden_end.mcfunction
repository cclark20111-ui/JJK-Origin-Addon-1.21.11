execute at @e[type=minecraft:warden,tag=cursed_origins_warden] run particle minecraft:sculk_soul ~ ~1 ~ 0.5 1 0.5 0.05 40
kill @e[type=minecraft:warden,tag=cursed_origins_warden]
tag @e[tag=cursed_origins_warden_target] remove cursed_origins_warden_target
