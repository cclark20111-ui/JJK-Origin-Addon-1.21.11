execute as @e[type=minecraft:warden,tag=cursed_origins_warden] unless entity @e[tag=cursed_origins_warden_target] run kill @s
execute unless entity @e[type=minecraft:warden,tag=cursed_origins_warden] run tag @e[tag=cursed_origins_warden_target] remove cursed_origins_warden_target
execute if entity @e[type=minecraft:warden,tag=cursed_origins_warden] run schedule function cursed_origins:warden_tick 10t
